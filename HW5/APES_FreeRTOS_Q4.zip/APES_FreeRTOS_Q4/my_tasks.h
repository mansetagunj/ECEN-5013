/*
 * my_tasks.h
 *
 *  Created on: 05-Apr-2018
 *      Author: Gunj Manseta
 */

#ifndef MY_TASKS_H_
#define MY_TASKS_H_


uint8_t Task1_init();
uint8_t Task2_init();


#endif /* MY_TASKS_H_ */
